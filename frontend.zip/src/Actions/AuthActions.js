import Dispatcher from '../dispatcher';
import ActionTypes from '../Constants';
import Api from '../Utils/Api';

const api = new Api();

class AuthActions{
    signin(email,password){
        api.login(email,password).then(value => {
          Dispatcher.dispatch({
              actionType: ActionTypes.ACCOUNT_SIGN_IN,
              payload:    value,
          });
        });
    }

    signup(fname,lname,email,password){
        api.signup(email,password,fname,lname).then(value => {
            Dispatcher.dispatch({
                actionType: ActionTypes.ACCOUNT_CREATED,
                payload: value,
            })
        })
    }
}

export default new AuthActions();