import { EventEmitter } from 'events';
import Dispatcher from '../dispatcher';
import ActionTypes from '../Constants';

const CHANGE = 'CHANGE';

let _userid;


class AuthStore extends EventEmitter {
    constructor() {
        super();
         Dispatcher.register(this._registerToActions.bind(this));
    }

    // Switches over the action's type when an action is dispatched.
    _registerToActions(action) {

        switch(action.actionType) {
            
            case ActionTypes.ACCOUNT_SIGN_IN:
                this._setUserid(action.payload);
                break;
            case ActionTypes.ACCOUNT_CREATED:
                this._setUserid(action.payload);
            default:
            break;
        }
    }

    _setUserid(userid){
        if(userid){
            let self = this;
            _userid = userid;
            setTimeout(() => { // Run after dispatcher has finished
                self.emit(CHANGE);
            }, 0);
        }
    }

    _getUserid(){
        return _userid;
    }

    addSigninListener(callback){
        this.on(CHANGE,callback);
    }

    removeSigninListener(callback){
        this.removeListener(CHANGE,callback);
    }
}
export default new AuthStore();